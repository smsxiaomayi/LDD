%simulate six-gene network with SDE
clear
N = 10^3;
deltat = 1;
T = 5*10^4; %sim3 T

x = xConstruct(N);
% y = zeros(5, T);
k = 5; gamma = 5*10^-3; sigma = 1.3; epsilon = 1;
for i = 1:T
    r1 = k*f2(x(:, 2)) - gamma.*x(:, 1); 
    r2 = k*f2(x(:, 1)) - gamma.*x(:, 2);
    r3 = k*f1(x(:, 1)).*f2(x(:, 4)) - gamma.*x(:, 3);
    r4 = k*f1(x(:, 1)).*f2(x(:, 3)) - gamma.*x(:, 4);
    r5 = k*f1(x(:, 2)).*f2(x(:, 6)) - gamma.*x(:, 5);
    r6 = k*f1(x(:, 2)).*f2(x(:, 5)) - gamma.*x(:, 6);
    
    x = x + [r1, r2, r3, r4, r5, r6]*deltat + sigma*sqrt(deltat)*randn(size(x));
    x(x<0) = 0;
    
    idx = ((x(:, 1)<epsilon) | (x(:, 2)<epsilon));
    x = x(~idx, :);
    
    nexit = sum(idx);
    x = [x; xConstruct(nexit)];
end

function y = f1(x) %active Hill function
y = x.^20./(x.^20 + 700^20);
end

function y = f2(x) %inactive Hill function
y = 1./(1+(x/200).^2);
end

function y = xConstruct(n)
y = [500*ones(n, 2), 40*ones(n, 4)] + 10*randn(n, 6);
end
