%simulate two-gene network model with tau-leaping
clear
N = 1000;
deltat = 0.5;
T = 5*10^4;
x = ones(N, 1)*225; y = ones(N, 1)*225;
for i = 1:T
    r1 = 0.003*x;
    r2 = 0.003*y;    
    r3 = max((0.01*x).^4./(1+(0.01*x).^4) - (0.003*y).^4./(1+(0.003*y).^4), 0);
    r4 = max((0.01*y).^4./(1+(0.01*y).^4) - (0.003*x).^4./(1+(0.003*x).^4), 0);
    
    n = poissrnd([r1, r2, r3, r4]*deltat);
    x = x - n(:, 1) + n(:, 3);
    y = y - n(:, 2) + n(:, 4);
    
    idx = ((x<=0)|(y<=0));
    x = x(~idx); y = y(~idx);
    
    nexit = sum(idx);

    x = [x; ones(nexit, 1)*225]; y = [y; ones(nexit, 1)*225];
end
