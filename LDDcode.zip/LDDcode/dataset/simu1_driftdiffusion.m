%simulate drift-diffusion model
N = 400; Deltat = 0.001; D = 0.04;
x = rand(N, 1)-0.5; y = rand(N, 1)/4+0.75; t = zeros(N, 1);
for i = 1:(2*10^5)
    t = t+1;
    x = x - (x.^3+x.*y)*Deltat + sqrt(D*Deltat)*randn(size(x));
    y = y - (x.^2/2+1/6)*Deltat + sqrt(D*Deltat)*randn(size(y));
    
    %reflect condition
    y(y>1) = 2-y(y>1);
    
    %remove exit points
    idx = (y<-2);
    n = sum(idx);
    x = x(~idx); y = y(~idx); t = t(~idx);
    
    %add new points
    if (n>0)
        x = [x; 0.1*rand(n, 1)-0.05]; y = [y; ones(n ,1)];
        t = [t; zeros(n, 1)];
    end
end
F = @(x,y) x.^4/4+x.^2.*y/2+y/6;
z = sqrt(D/4)*randn(400, 48);
