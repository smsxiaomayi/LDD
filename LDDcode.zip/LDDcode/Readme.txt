######The manual of LDD (landscape of Landscape of Differentiation Dynamics) ######

"Quantifying pluripotency landscape of cell differentiation from scRNA-seq data by continuous birth-death process"
by Jifan Shi, Tiejun Li, Luonan Chen, Kazuyuki Aihara (2019)

The matlab code is edited under MATLAB 2017b and R code is edited under R3.5.0.

$"dataset" document:
	It includes three simulated datasets (including source files to simulate by matlab) and four real datasets after preprocessed. The ".mat" files can be loaded by matlab directly, or using "R.matlab" package by R.
	The LDD results of three simulated models are also contained in the corresponding files. "LODD_result.mat" contains the pseudo-time computed by LDD and true labels for all seven datasets.

$LDD codes:
 @For matlab code:
  potential_F.m: [V_hat, P_net, C_kind, mu_hat, P_hat] = potential_F(data, K_kind)
	This is the main file to compute potential constructed by LDD.
	Input "data" is the preprocessed gene expression data matrix with rows as sampled observations and columns as gene variables. Input "K_kind" is a scaler determining the number of clusters.
	Ouputs include LDD potential "V_hat", differentiation graph "P_net", cluster index for each sample "C_kind", stationary distribution on clusters "mu_hat", and coarse-grained matrix "P_hat".
	Only "P_net" and "V_hat" are useful for analysis of cell differentiation, where "P_net" ditermines the differentiatial graph and "V_hat" determines the direction. The cells differentiate from high "V_hat" to low, and "-V_hat" is considered as a presentation of pseudo-time.
  potential_F_clustered.m: [V_hat, P_net, mu_hat, P_hat] = potential_F_clustered(data, C_kind, K_kind)
	If we already clustered the preprocessed data into several clusters, we can use potential_F_clustered.m instead of potential_F.m.
	Inputs "data" and "K_kind" are samples and cluster number. Input "C_kind" is the cluter index for each sample.
	Outputs are LDD potential "V_hat", differentiation graph "P_net", stationary distribution on clusters "mu_hat", and coarse-grained matrix "P_hat".
	Only "V_hat" and "P_hat" are useful for constructing differentiatial paths.
  EWSindex_KS_onetime.m: beta = EWSindex_KS_onetime(data)
	This function is a subfunction used in the potential_F and potential_F_clustered. It is used to compute the cell net-flow of each cluster.
  V_potential.m: V = V_potential(P, R, epsilon)
	This function is a subfunction used in the potential_F and potential_F_clustered. It is used to compute potential V_hat for each cluster.
	
 @For R code:
	LDD.r: It contains four functions used to compute the LDD potential and differentiation graph. "LDDpotential" and "LDDpotential_clustered" are the main functions to be used.
		LDDpotential <- function(GeneExp, K_kind = 5)
		  Input "GeneExp" is a numerical matrix with rows for observations and columns for gene variables. K_kind is the cluster number.
		  Output is a list, contain 6 elements, i.e. differentiation graph matrix "P_net", LDD potential "V_hat" of every cluster, cluster index for each sample "C_kind", cluster number "K_kind", stationary distribution for each cluster "mu_hat", and coarse-grained transfer operator matrix "P_hat".
		  Only "P_net" and "V_hat" are useful for analysis of cell differentiation, where "P_net" ditermines the differentiatial graph and "V_hat" determines the direction. The cells differentiate from high "V_hat" to low, and "-V_hat" is considered as a presentation of pseudo-time.
		LDDpotential <- function(GeneExp, C_kind, K_kind)
		  If we already clustered the preprocessed data into several clusters, we can use LDDpotential_clustered instead of LDDpotential.
		  Input "GeneExp" is a numerical matrix with rows for observations and columns for gene variables. C_kind is the cluster index for each sample. K_kind is the cluster number.
		  Output is a list, contain 4 elements, i.e. differentiation graph matrix "P_net", LDD potential "V_hat" of every cluster, stationary distribution for each cluster "mu_hat", and coarse-grained transfer operator matrix "P_hat".
		  Only "P_net" and "V_hat" are useful for analysis of cell differentiation, where "P_net" ditermines the differentiatial graph and "V_hat" determines the direction. The cells differentiate from high "V_hat" to low, and "-V_hat" is considered as a presentation of pseudo-time.
	main.r: An file contains examples to run LDD.

 @Remark:
	The numerical results of "V_hat" for matlab code and R code are slight differentces while "P_net" are the same, because the fitting function used in matlab is "ksdensity" while in R is "density" in "stats" package. But the pseudo-time orders of clusters are the same.