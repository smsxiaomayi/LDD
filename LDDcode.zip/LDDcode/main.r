library(R.matlab)

source('LDD.r')

#Simu1 example
dataExp1 <- readMat(file.path("./dataset/", "simu1.mat"))
out1 <- LDDpotential(dataExp1$Y2, K_kind = 4)
out1$P_net
out1$V_hat

#Simu2 example
dataExp2 <- readMat(file.path("./dataset/", "simu2.mat"))
out2 <- LDDpotential(dataExp2$Y2, K_kind = 7)
out2$P_net
out2$V_hat

#Simu3 example
dataExp3 <- readMat(file.path("./dataset/", "simu3.mat"))
out3 <- LDDpotential(dataExp3$Y2, K_kind = 6)
out3$P_net
out3$V_hat

#Guo
dataGuo <- readMat(file.path("./dataset/", "re_guo.mat"))
outGuo <- LDDpotential_clustered(dataGuo$Y2, as.vector(dataGuo$C.kind), K_kind = 4)
outGuo$P_net
outGuo$V_hat

#Nef
dataNef <- readMat(file.path("./dataset/", "re_nef.mat"))
outNef <- LDDpotential_clustered(dataNef$Y2, as.vector(dataNef$C.kind), K_kind = 5)
outNef$P_net
outNef$V_hat

#Xu
dataXu <- readMat(file.path("./dataset/", "re_xu.mat"))
outXu <- LDDpotential_clustered(dataXu$Y2, as.vector(dataXu$C.kind), K_kind = 5)
outXu$P_net
outXu$V_hat

#Furlan
dataFurlan <- readMat(file.path("./dataset/", "re_Furlan.mat"))
outFurlan <- LDDpotential_clustered(dataFurlan$Y2, as.vector(dataFurlan$C.kind), K_kind = 4)
outFurlan$P_net
outFurlan$V_hat
