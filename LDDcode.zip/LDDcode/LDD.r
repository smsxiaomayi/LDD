

LDDpotential <- function(GeneExp, K_kind = 5){
    library(BiocNeighbors)
    library(Matrix)
    dimGene <- dim(GeneExp); #N samples * m variables
    knei = 10; #number of knn
    
    knnout <- findKNN(GeneExp, k = knei);
    epsilon <- median(knnout$distance)^2/2; #parameter in diffusion distance
    
    #Transition matrix and stable distribution
    xi = rep(1:dimGene[1], knei); xj = as.vector(knnout$index); xval = exp(-as.vector(knnout$distance)^2/(4*epsilon));
    D_m <- sparseMatrix(i = c(xi, xj), j = c(xj, xi), x = c(xval, xval), dims = c(dimGene[1], dimGene[1]), use.last.ij = TRUE);
    mu <- rowSums(D_m);
    P0 = D_m/(sqrt(mu)%o%sqrt(mu));
    mu <- rowSums(P0);
      
    P <- P0/mu; mu <- mu/sum(mu);
    
    #kmeans cluster
    cl <- kmeans(GeneExp, K_kind);
    C_kind = cl$cluster;
    
    #compute escaping rate of each cluster's samples, and convert beta into R
    beta_hat = vector(length = K_kind); N_hat = vector(length = K_kind);
    for (i in 1:K_kind){
      tempdata = GeneExp[C_kind==i,];
      N_hat[i] = nrow(tempdata);
      beta_hat[i] = LDDbeta(tempdata);
    }
    beta_hat = beta_hat - as.vector(N_hat%*%beta_hat)/sum(N_hat); #post-process the net-flow
    
    #compute P_hat and P_net
    P_hat = matrix(nrow = K_kind, ncol = K_kind);
    mu_hat = vector(length = K_kind);
    P_net = matrix(nrow = K_kind, ncol = K_kind);
    for (i in 1:K_kind){
      for (j in 1:K_kind){
        P_net[i, j] = sum(mu[C_kind==i]*P[C_kind==i, C_kind==j]);
        P_hat[i, j] = sum(mu[C_kind==j])*mean(P[C_kind==i, C_kind==j]);
      }
      mu_hat[i] = sum(mu[C_kind==i]);
    }
    
    #compute the V-potential of each cluster
    V_hat = LDDV(P_hat, beta_hat, epsilon);
    
    return(list(P_net = P_net, V_hat = V_hat, C_kind = C_kind, K_kind = K_kind, mu_hat = mu_hat, P_hat = P_hat));
    
}

LDDpotential_clustered <- function(GeneExp, C_kind, K_kind){
  library(BiocNeighbors)
  library(Matrix)
  dimGene <- dim(GeneExp); #N samples * m variables
  knei = 10; #number of knn
  
  knnout <- findKNN(GeneExp, k = knei);
  epsilon <- median(knnout$distance)^2/2; #parameter in diffusion distance
  
  #Transition matrix and stable distribution
  xi = rep(1:dimGene[1], knei); xj = as.vector(knnout$index); xval = exp(-as.vector(knnout$distance)^2/(4*epsilon));
  D_m <- sparseMatrix(i = c(xi, xj), j = c(xj, xi), x = c(xval, xval), dims = c(dimGene[1], dimGene[1]), use.last.ij = TRUE);
  mu <- rowSums(D_m);
  P0 = D_m/(sqrt(mu)%o%sqrt(mu));
  mu <- rowSums(P0);
  
  P <- P0/mu; mu <- mu/sum(mu);
  
  #compute escaping rate of each cluster's samples, and convert beta into R
  beta_hat = vector(length = K_kind); N_hat = vector(length = K_kind);
  for (i in 1:K_kind){
    tempdata = GeneExp[C_kind==i,];
    N_hat[i] = nrow(tempdata);
    beta_hat[i] = LDDbeta(tempdata);
  }
  beta_hat = beta_hat - as.vector(N_hat%*%beta_hat)/sum(N_hat); #post-process the net-flow
  
  #compute P_hat and P_net
  P_hat = matrix(nrow = K_kind, ncol = K_kind);
  mu_hat = vector(length = K_kind);
  P_net = matrix(nrow = K_kind, ncol = K_kind);
  for (i in 1:K_kind){
    for (j in 1:K_kind){
      P_net[i, j] = sum(mu[C_kind==i]*P[C_kind==i, C_kind==j]);
      P_hat[i, j] = sum(mu[C_kind==j])*mean(P[C_kind==i, C_kind==j]);
    }
    mu_hat[i] = sum(mu[C_kind==i]);
  }
  
  #compute the V-potential of each cluster
  V_hat = LDDV(P_hat, beta_hat, epsilon);
  
  return(list(P_net = P_net, V_hat = V_hat, mu_hat = mu_hat, P_hat = P_hat));
  
}

LDDbeta <- function(Genedata){
  dimGene = dim(Genedata);
  if(dimGene[1]<=2){
    return(beta = 0);
  }
  tempbeta = vector(length = dimGene[2]);
  for (i in 1:dimGene[2]){
    tempdata = Genedata[,i];
    x1 = min(tempdata); x2 = max(tempdata);
    den <- density(tempdata, n = 1000, from = x1, to = x2);
    x <- den$x;
    f = den$y/sum(den$y*(x[2]-x[1]));
    tempbeta[i] = (f[length(f)]-f[length(f)-1])/(x[length(x)] - x[length(x)-1]) - (f[2] - f[1])/(x[2] - x[1]);
  }
  return(-sum(tempbeta, na.rm = TRUE));
}

LDDV <- function(P, R, epsilon){
  A = P - diag(dim(P)[1]); 
  B = svd(A); #A = B$u %*% diag(B$d) %*% t(B$v);
  invd = diag(B$d);
  invd[invd<10^-3]=0;
  invd[invd!=0] = 1/invd[invd!=0];
  V = -B$v %*% invd %*% t(B$u) %*% R; 
  return(epsilon*V); #V = -pinv(A)*epsilon*R;
}
