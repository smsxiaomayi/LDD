%Compute LDD potential with estimated backward operator L and net-flow rate R.

function V = V_potential(P, R, epsilon)
%P is n*n transition matrix where n is the number of samples
%R is n*1 which represents (net generate rate) = -(escaping rate) of each sample position.
%epsilon is the scale of Laplacian matrix
%L_lap = (P-speye(size(P)))/epsilon; V = -L_lap\R;


A = P - eye(size(P)); [B,S,C] = svd(A); %A = B*S*C';
S(S<10^-3)=0;
A = B*S*C';
V = -pinv(A)*epsilon*R;

end