function [V_hat, P_net, C_kind, mu_hat, P_hat] = potential_F(data, K_kind)
%Compute LDD potential decomposition from scRNA-seq data.
%Input:
%  data must be normalized and pre-processed before. data is N*m with N samples and m variables.
%  N > k, if k nearest neighbor points are used.
%  K_kind is the number of clusters. (default 5)
%Output:
% V_hat is the LDD potential. P_net determines the differentiatial network. C_kind is 
% the cluster index of each sample. mu_hat is the stationary distribution on clusters. 
% P_hat is the coarse-grained matrix between clusters.

if (nargin == 1)
    K_kind = 5; %default K_kind clusters
end

[N, ~] = size(data);

% make transition matrix of samples (backward operator)
k = 10; %use k nearest neighbors.
dist = 'sqeuclidean'; %kmeans distance

[idx, D_v] = knnsearch(data, data, 'Distance', 'euclidean', 'K', k+1);
epsilon = median(D_v(:))^2/2;%parameter in diffusion distance
idx = idx(:, 2:end); D_v = exp(-D_v(:, 2:end).^2/(4*epsilon));
% make network
sparseid = [repmat((1:N)', k, 1), idx(:), D_v(:)];
sparseid = unique([sparseid; sparseid(:, 2), sparseid(:, 1), sparseid(:, 3)], 'rows');
D_m = sparse(sparseid(:, 1), sparseid(:, 2), sparseid(:, 3), N, N);

%transition matrix and stable distribution
mu = sum(D_m, 2);
P0 = D_m./(sqrt(mu)*sqrt(mu')); %symmetric matrix
mu = sum(P0, 2);
P = P0./mu; mu = mu./sum(mu);

%kmeans cluster
C_kind = kmeans(data, K_kind, 'Distance', dist); 

% compute escaping rate of each cluster's samples, and convert beta into R
beta_hat = zeros(K_kind, 1); N_hat = zeros(K_kind, 1);
for i = 1:K_kind
    tempdata = data(C_kind==i, :); 
    N_hat(i) = size(tempdata, 1);
    beta_hat(i) = EWSindex_KS_onetime(tempdata);
end
beta_hat = beta_hat - sum(N_hat.*beta_hat)/sum(N_hat); %post-process the net-flow

%compute P_hat and P_net
P_hat = zeros(K_kind);
mu_hat = zeros(K_kind, 1);
P_net = zeros(K_kind);
for i = 1:K_kind
    for j = 1:K_kind
        temp = P(C_kind==i, C_kind ==j);
%         P_hat(i, j) = mean(temp(:));
        P_hat(i, j) = mean(temp(:))*sum(mu(C_kind==j));
        P_net(i, j) = sum(mu(C_kind==i)'*temp);
    end
    mu_hat(i) = sum(mu(C_kind==i));
end

% compute the V-potential of each cluster
V_hat = V_potential(P_hat, beta_hat, epsilon);
end
