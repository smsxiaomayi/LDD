% Using ksdensity to compute net-flow rate "beta" for one time point
% Input data is N*m matrix where N is the number of samples, m is the number of variables

function beta = EWSindex_KS_onetime(data)
    sdata = size(data);
    if (length(sdata)~=2)
        error('Error input data size in EWSindex_KS.m!!!\n')
    end
    if(sdata(1)<=2)
        beta = 0;
    else
        betatemp = zeros(sdata(2), 1);
        for j = 1:sdata(2)
            temp = data(:, j);
            x1 = min(temp); x2 = max(temp);
            [f, xi] = ksdensity(temp, linspace(x1, x2, 1000));
            f = f/sum(f*(xi(2)-xi(1)));
            betatemp(j) = (f(end)-f(end-1))/(xi(end)-xi(end-1)) - (f(2)-f(1))/(xi(2)-xi(1));
        end
            beta = -sum(betatemp(~isnan(betatemp)));
    end
end
